﻿Imports System.Data.OleDb

Public Class Form1
    Dim connString As String = "Provider = Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Movies.accdb"
    Dim conn As New OleDbConnection(connString)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Display_Data()
        combo1()

    End Sub

    Private Sub combo1()
        conn.Open()
        Dim strsql As New OleDbCommand(" select distinct Genre from Movies", conn)
        Dim reader As OleDb.OleDbDataReader = strsql.ExecuteReader
        cboGenre.Items.Clear()
        While reader.Read()
            cboGenre.Items.Add(reader("Genre"))
        End While
        conn.Close()
        cboGenre.Items.Insert(0, "")
    End Sub

    Private Sub Display_Data()
        Dim dtMovies As New DataTable

        Using conn As New OleDbConnection(connString)
            Using cmd As New OleDbCommand("SELECT * FROM Movies", conn)
                conn.Open()

                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                dtMovies.Load(reader)

            End Using
        End Using
        MovieDisplay.DataSource = dtMovies
    End Sub

    Private Sub FindGenre()
        conn.Open()
        Dim cmd As New OleDbCommand("SELECT * FROM Movies WHERE Genre like '%" + cboGenre.Text + "%'", conn)
        Dim da As New OleDbDataAdapter
        Dim dtMovies As New DataTable

        da.SelectCommand = cmd
        dtMovies.Clear()
        da.Fill(dtMovies)
        MovieDisplay.DataSource = dtMovies
        conn.Close()
    End Sub

    Private Sub FindActor()
        conn.Open()
        Dim cmd As New OleDbCommand("SELECT * FROM Movies WHERE Actor like '%" + txtActors.Text + "%'", conn)
        Dim da As New OleDbDataAdapter
        Dim dtMovies As New DataTable

        da.SelectCommand = cmd
        dtMovies.Clear()
        da.Fill(dtMovies)
        MovieDisplay.DataSource = dtMovies
        conn.Close()

    End Sub

    Private Sub txtActors_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtActors.TextChanged
        FindActor()
    End Sub

    Private Sub cboGenre_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboGenre.SelectedIndexChanged
        FindGenre()
    End Sub

    Private Sub FindRT()

        Dim Range As String


        If cboRottom.Text = "0-39" Then
            Range = "WHERE RottenTomatoes BETWEEN 0 AND 39"
        ElseIf cboRottom.Text = "40-79" Then
            Range = "WHERE RottenTomatoes BETWEEN 40 AND 79"
        Else cboRottom.Text = "80-100"
            Range = "WHERE RottenTomatoes BETWEEN 80 AND 100"
        End If

        conn.Open()
        Dim cmd As New OleDbCommand("SELECT * FROM Movies " + Range, conn)
        Dim da As New OleDbDataAdapter
        Dim dtMovies As New DataTable

        da.SelectCommand = cmd
        dtMovies.Clear()
        da.Fill(dtMovies)
        MovieDisplay.DataSource = dtMovies
        conn.Close()
    End Sub

    Private Sub FindYear()
        conn.Open()
        Dim cmd As New OleDbCommand("SELECT * FROM Movies WHERE ReleaseDecade like '%" + cboReDate.Text + "%'", conn)
        Dim da As New OleDbDataAdapter
        Dim dtMovies As New DataTable

        da.SelectCommand = cmd
        dtMovies.Clear()
        da.Fill(dtMovies)
        MovieDisplay.DataSource = dtMovies
        conn.Close()
    End Sub

    Private Sub cboRottom_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRottom.SelectedIndexChanged
        FindRT()
    End Sub

    Private Sub cboReDate_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboReDate.SelectedIndexChanged
        FindYear()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        cboRottom.Text = ""
        cboReDate.Text = ""
        cboGenre.Text = ""
        txtActors.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
